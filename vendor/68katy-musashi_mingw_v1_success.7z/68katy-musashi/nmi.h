#ifndef _NMI_H
#define _NMI_H

void nmi_device_reset(void);
void nmi_device_update(void);
int nmi_device_ack(void);

#endif
